<?php
// Heading
$_['heading_title']     = 'Últimos pedidos';

// Column
$_['column_order_id']   = 'Pedido Nº';
$_['column_customer']   = 'Cliente';
$_['column_status']     = 'Situação';
$_['column_total']      = 'Total';
$_['column_date_added'] = 'Data';
$_['column_action']     = 'Ação';