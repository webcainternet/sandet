<?php
// Heading
$_['heading_title']    = 'Impostos';

// Text
$_['text_total']       = 'Total de pedidos';
$_['text_success']	   = 'Impostos modificados com sucesso!';
$_['text_edit']        = 'Configurações dos Impostos';

// Entry
$_['entry_status']     = 'Situação';
$_['entry_sort_order'] = 'Posição';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar os Impostos!';