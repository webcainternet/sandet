<?php
// Heading
$_['heading_title']    = 'Menu do cliente';

$_['text_module']      = 'Módulos';
$_['text_success']     = 'Módulo Menu do cliente modificado com sucesso!';
$_['text_edit']        = 'Configurações do módulo Menu do cliente';

// Entry
$_['entry_status']     = 'Situação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar o módulo Menu do cliente!';