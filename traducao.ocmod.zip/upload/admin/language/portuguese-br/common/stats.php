<?php
$_['text_complete_status']   = 'Finalizados'; 
$_['text_processing_status'] = 'Processando'; 
$_['text_other_status']      = 'Outras situações'; 