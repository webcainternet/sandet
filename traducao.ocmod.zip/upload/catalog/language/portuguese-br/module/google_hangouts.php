<?php
// Heading
$_['heading_title']  = 'Hangout';